using System;
using System.Diagnostics;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;

namespace FSOCX86
{
    public partial class Form1
    {
        private const uint DELIVERY_FIRMWARE = 0x4D333301U;
        private const long DELIVERY_READ_BUDGET_MS = 2000;
        private DeliveryMetricsCalculator deliveryCalculator;
        private TxCounterSnapshot previousDeliveryLineSnapshot;
        private string lastDeliveryAvailability;

        // The user's supplied Designer wires this label event. Keep the
        // Designer byte-for-byte unchanged; the label needs no click action.
        private void label14_Click(object sender, EventArgs e) { }

        private void ResetDeliveryMetrics()
        {
            if (deliveryCalculator != null) deliveryCalculator.Reset();
            previousDeliveryLineSnapshot = null;
            lastDeliveryAvailability = null;
        }

        // Preserve the supplied Designer and the original six cell positions.
        // Names, not display indices, identify the five new measurement cells.
        private void AddMeasuredMimoRow(TxCounterSnapshot optical,
            string time, string mode, string ber1, string ber2, string aber, string rfBer)
        {
            int index = dgvMimoBer.Rows.Add(time, mode, ber1, ber2, aber, rfBer);
            DataGridViewRow row = dgvMimoBer.Rows[index];
            SetDeliveryCell(row, "Rx1", "Unavailable");
            SetDeliveryCell(row, "Rx2", "Unavailable");
            SetDeliveryCell(row, "OBER", "Unavailable");
            SetDeliveryCell(row, "Throughput", "Unavailable");
            SetDeliveryCell(row, "Delivery", "Unavailable");
            try
            {
                // Older FPGA images still have measured per-lane RX counters.
                // Never substitute configured capacity for measured delivery.
                SetFallbackLineRates(row, optical);
                DeliverySnapshot measured;
                string reason;
                if (!TryReadDeliverySnapshot(optical, out measured, out reason))
                {
                    if (deliveryCalculator != null) deliveryCalculator.Reset();
                    LogDeliveryAvailability(reason);
                    return;
                }
                if (deliveryCalculator == null) deliveryCalculator = new DeliveryMetricsCalculator();
                DeliveryMetricsResult result = deliveryCalculator.Update(measured, true);
                LogDeliveryAvailability(result.Reason);
                if (!result.IsValid)
                {
                    string text = result.State == DeliveryMetricsState.Baseline ? "Measuring..." : "Unavailable";
                    SetDeliveryCell(row, "OBER", text);
                    SetDeliveryCell(row, "Throughput", text);
                    SetDeliveryCell(row, "Delivery", text);
                    return;
                }
                SetDeliveryCell(row, "Rx1", FormatDeliveryNumber(result.Rx1Mbps, "0.000"));
                SetDeliveryCell(row, "Rx2", FormatDeliveryNumber(result.Rx2Mbps, "0.000"));

                // These counters observe the optical reconstruction path only.
                // RF runs a different packet protocol; never relabel optical
                // counts or configured 1 Mbps as measured RF output delivery.
                bool rfOwnsOutput = rfBackup != null && rfBackup.Requested;
                SetDeliveryCell(row, "OBER", rfOwnsOutput ? "Unavailable (RF)" :
                    FormatDeliveryNumber(result.OutputBer, "0.000E+00"));
                SetDeliveryCell(row, "Throughput", rfOwnsOutput ? "Unavailable (RF)" :
                    FormatDeliveryNumber(result.GoodputMbps, "0.000000"));
                SetDeliveryCell(row, "Delivery", rfOwnsOutput ? "Unavailable (RF)" :
                    FormatDeliveryNumber(result.DeliveryPercent, "0.000000"));
                LogDeliveryResult(measured, result, rfOwnsOutput);
            }
            catch (Exception ex)
            {
                if (deliveryCalculator != null) deliveryCalculator.Reset();
                SetDeliveryCell(row, "OBER", "Unavailable");
                SetDeliveryCell(row, "Throughput", "Unavailable");
                SetDeliveryCell(row, "Delivery", "Unavailable");
                LogDeliveryAvailability("measurement read exception: " + ex.Message);
                // Optional telemetry cannot stop existing optical/RF polling.
            }
            finally
            {
                if (rfBackup != null && rfBackup.Requested)
                {
                    SetDeliveryCell(row, "OBER", "Unavailable (RF)");
                    SetDeliveryCell(row, "Throughput", "Unavailable (RF)");
                    SetDeliveryCell(row, "Delivery", "Unavailable (RF)");
                }
            }
        }

        private void LogDeliveryResult(DeliverySnapshot measured, DeliveryMetricsResult result, bool rfOwnsOutput)
        {
            string message = "DELIVERY FSO | epoch/mode=" + measured.EpochMode.ToString("X8") +
                    " token=" + measured.Token.ToString(CultureInfo.InvariantCulture) +
                    " wallTicks=" + measured.Ticks.ToString(CultureInfo.InvariantCulture) +
                    " retiredTicks=" + measured.RetiredTicks.ToString(CultureInfo.InvariantCulture) +
                    " expected=" + measured.ExpectedBlocks.ToString(CultureInfo.InvariantCulture) +
                    " complete=" + measured.CompleteBlocks.ToString(CultureInfo.InvariantCulture) +
                    " good=" + measured.GoodBlocks.ToString(CultureInfo.InvariantCulture) +
                    " comparedBits=" + measured.ComparedBits.ToString(CultureInfo.InvariantCulture) +
                    " errorBits=" + measured.ErrorBits.ToString(CultureInfo.InvariantCulture) +
                    " rx1LineBits=" + measured.Rx1LineBits.ToString(CultureInfo.InvariantCulture) +
                    " rx2LineBits=" + measured.Rx2LineBits.ToString(CultureInfo.InvariantCulture) +
                    " | goodput=" + FormatDeliveryNumber(result.GoodputMbps, "0.000000") +
                    " Mbps | delivery=" + FormatDeliveryNumber(result.DeliveryPercent, "0.000000") +
                    "% | outputBER=" + FormatDeliveryNumber(result.OutputBer, "0.000E+00") +
                    (rfOwnsOutput ? " | optical-only counters; RF owns displayed text" : "");
            if (ActiveMimoRun) AddMimoLog(message); else AddLog(message);
        }

        private void LogMeasuredSisoDelivery(TxCounterSnapshot optical)
        {
            // The Data-tab layout is unchanged. SISO receives the same measured
            // source-cohort audit in its existing log, without adding MIMO rows.
            try
            {
                DeliverySnapshot measured;
                string reason;
                if (!TryReadDeliverySnapshot(optical, out measured, out reason))
                {
                    if (deliveryCalculator != null) deliveryCalculator.Reset();
                    LogDeliveryAvailability(reason);
                    return;
                }
                if (deliveryCalculator == null) deliveryCalculator = new DeliveryMetricsCalculator();
                DeliveryMetricsResult result = deliveryCalculator.Update(measured, true);
                LogDeliveryAvailability(result.Reason);
                if (result.IsValid) LogDeliveryResult(measured, result, false);
            }
            catch (Exception ex)
            {
                if (deliveryCalculator != null) deliveryCalculator.Reset();
                LogDeliveryAvailability("measurement read exception: " + ex.Message);
            }
        }

        private static string FormatDeliveryNumber(double? value, string format)
        {
            return value.HasValue ? value.Value.ToString(format, CultureInfo.InvariantCulture) : "N/A";
        }

        private void SetDeliveryCell(DataGridViewRow row, string name, string value)
        {
            // Legacy six-column offline fixtures are also supported. The actual
            // supplied Designer contains all eleven columns and is unchanged.
            if (dgvMimoBer.Columns.Contains(name)) row.Cells[name].Value = value;
        }

        private void LogDeliveryAvailability(string reason)
        {
            if (lastDeliveryAvailability == reason) return;
            lastDeliveryAvailability = reason;
            if (ActiveMimoRun) AddMimoLog("DELIVERY | " + reason);
            else AddLog("DELIVERY | " + reason);
        }

        private void SetFallbackLineRates(DataGridViewRow row, TxCounterSnapshot optical)
        {
            TxCounterSnapshot previous = previousDeliveryLineSnapshot;
            previousDeliveryLineSnapshot = optical;
            TxTimingWindow timing;
            string reason;
            if (!SameCounterRun(previous, optical) ||
                !TxTimingWindow.TryCreate(previous, optical, out timing, out reason)) return;
            double maximum = TxTimingWindow.NominalMbps(optical.Status) * 1000000.0 *
                (timing.Seconds + timing.HostTimingAllowance) * 1.25 + 65536.0;
            if (timing.Seconds > 3.0 || timing.DeltaRx1 > maximum || timing.DeltaRx2 > maximum ||
                timing.DeltaErrors1 > timing.DeltaRx1 || timing.DeltaErrors2 > timing.DeltaRx2) return;
            SetDeliveryCell(row, "Rx1", timing.Rx1Mbps.ToString("0.000", CultureInfo.InvariantCulture));
            SetDeliveryCell(row, "Rx2", timing.Rx2Mbps.ToString("0.000", CultureInfo.InvariantCulture));
        }

        private bool TryReadDeliverySnapshot(TxCounterSnapshot optical,
            out DeliverySnapshot snapshot, out string reason)
        {
            snapshot = null;
            reason = "delivery telemetry unavailable; use the matching V3.3 FPGA";
            Stopwatch readBudget = Stopwatch.StartNew();
            uint magic;
            if (!ReadDeliveryWord(90, out magic, readBudget, ref reason) || magic != DELIVERY_FIRMWARE) return false;
            if (optical == null || !optical.HasModeEpoch)
            { reason = "optical run epoch unavailable"; return false; }
            uint requested, completed = 0;
            if (!ReadDeliveryWord(91, out requested, readBudget, ref reason)) return false;
            bool ready = false;
            for (int attempt = 0; attempt < 8; attempt++)
            {
                if (!ReadDeliveryWord(92, out completed, readBudget, ref reason)) return false;
                if (completed == requested) { ready = true; break; }
                Thread.Sleep(1);
            }
            if (!ready) { reason = "delivery snapshot timed out"; return false; }
            uint[] words = new uint[22];
            for (int i = 0; i < words.Length; i++)
                if (!ReadDeliveryWord((byte)(93 + i), out words[i], readBudget, ref reason)) return false;
            uint finalToken, finalEpoch;
            if (!ReadDeliveryWord(92, out finalToken, readBudget, ref reason) ||
                !ReadDeliveryWord(93, out finalEpoch, readBudget, ref reason)) return false;
            if (finalToken != requested || finalEpoch != words[0] || words[0] != optical.ModeEpoch)
            { reason = "delivery snapshot token/run changed during read"; return false; }
            if ((words[1] & 3U) != 3U || (words[0] & 3U) > MIMO_MODE_SMP)
            { reason = "delivery measurement stopped or unsupported"; return false; }
            if ((words[1] & 0x20U) == 0)
            { reason = "delivery measurement collecting the first complete source cohort"; return false; }
            if (words[18] != 250000000U || words[19] != 32U)
            { reason = "delivery clock/block format mismatch"; return false; }
            snapshot = new DeliverySnapshot
            {
                Token = requested, EpochMode = words[0], Flags = words[1],
                Ticks = JoinDeliveryWords(words[2], words[3]),
                ExpectedBlocks = JoinDeliveryWords(words[4], words[5]),
                CompleteBlocks = JoinDeliveryWords(words[6], words[7]),
                GoodBlocks = JoinDeliveryWords(words[8], words[9]),
                ComparedBits = JoinDeliveryWords(words[10], words[11]),
                ErrorBits = JoinDeliveryWords(words[12], words[13]),
                Rx1LineBits = JoinDeliveryWords(words[14], words[15]),
                Rx2LineBits = JoinDeliveryWords(words[16], words[17]),
                RetiredTicks = JoinDeliveryWords(words[20], words[21])
            };
            reason = "coherent optical delivery snapshot";
            return true;
        }

        private bool ReadDeliveryWord(byte id, out uint word, Stopwatch budget, ref string reason)
        {
            word = 0;
            if (budget.ElapsedMilliseconds > DELIVERY_READ_BUDGET_MS)
            { reason = "delivery USB read exceeded the 2 s freshness budget"; return false; }
            // Native synchronous I/O cannot be cancelled here. Reject an old
            // bank as soon as the call returns, even if it reports success.
            bool success = ReadStatusWordRaw(id, out word);
            if (budget.ElapsedMilliseconds > DELIVERY_READ_BUDGET_MS)
            { reason = "delivery USB read exceeded the 2 s freshness budget"; return false; }
            return success;
        }

        private static ulong JoinDeliveryWords(uint low, uint high)
        { return ((ulong)high << 32) | low; }
    }
}
